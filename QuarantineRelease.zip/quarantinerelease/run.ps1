param($Request, $TriggerMetadata)

$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $true

function Write-JsonResponse {
    param(
        [int]$StatusCode = 200,
        [Parameter(Mandatory=$true)]$BodyObject
    )
    return @{
        statusCode = $StatusCode
        headers    = @{ 'Content-Type' = 'application/json' }
        body       = ($BodyObject | ConvertTo-Json -Depth 12)
    }
}

function BadRequest($msg) {
    Write-JsonResponse -StatusCode 400 -BodyObject @{ status='error'; message=$msg }
}

function ToBool($v) {
    if ($null -eq $v) { return $null }
    if ($v -is [bool]) { return $v }
    $s = $v.ToString().Trim().ToLowerInvariant()
    return ($s -in @('true','1','yes','y'))
}

function Get-RawBodyString {
    param($Req)
    if (-not $Req.Body) { return $null }

    $t = $Req.Body.GetType().FullName
    switch ($t) {
        'System.String' { return $Req.Body }
        'System.Byte[]' { return [Text.Encoding]::UTF8.GetString($Req.Body) }
        'System.IO.MemoryStream' {
            $sr = [IO.StreamReader]::new($Req.Body)
            return $sr.ReadToEnd()
        }
        default {
            if ($Req.Body -is [hashtable] -or $Req.Body -is [pscustomobject]) {
                return ($Req.Body | ConvertTo-Json -Depth 20)
            }
            return [string]$Req.Body
        }
    }
}

try {
    # ---- Body parsing ----
    $payload = $null
    $raw = Get-RawBodyString -Req $Request

    if ($raw -and ($raw.Trim().StartsWith('{') -or $raw.Trim().StartsWith('['))) {
        try {
            $payload = $raw | ConvertFrom-Json -Depth 20 -ErrorAction Stop
        } catch {
            return Write-JsonResponse -StatusCode 400 -BodyObject @{
                status = 'error'
                message = 'Invalid JSON body.'
                detail = $_.Exception.Message
                rawPreview = ($raw.Substring(0, [Math]::Min(200, $raw.Length)))
            }
        }
    }
    elseif ($Request.Body -is [hashtable] -or $Request.Body -is [pscustomobject]) {
        $payload = $Request.Body
    }

    if (-not $payload) {
        # Fallback to minimum querystring
        if ($Request.Query -and ($Request.Query.MessageId -or $Request.Query.Identity)) {
            $payload = [pscustomobject]@{
                MessageId     = $Request.Query.MessageId
                Identity      = $Request.Query.Identity
                ReleaseToAll  = ToBool $Request.Query.ReleaseToAll
                Users         = $null
                AllowSender   = ToBool $Request.Query.AllowSender
                ReportFalsePositive = ToBool $Request.Query.ReportFalsePositive
                EntityType    = ($Request.Query.EntityType ?? 'Email')
            }
        } else {
            return BadRequest("Body JSON ausente. Envie application/json com { MessageId ou Identity }.")
        }
    }

    # ---- Required App Setting: EXO_ORG ----
    $org = $env:EXO_ORG
    if (-not $org) {
        return BadRequest("Defina a App Setting 'EXO_ORG' com seu <tenant>.onmicrosoft.com.")
    }

    # ---- Input Parametersa ----
    $messageId     = $payload.MessageId
    $identity      = $payload.Identity
    $releaseToAll  = ToBool $payload.ReleaseToAll
    $users         = $payload.Users
    $allowSender   = ToBool $payload.AllowSender
    $reportFP      = ToBool $payload.ReportFalsePositive
    $entityType    = $payload.EntityType
    if (-not $entityType) { $entityType = 'Email' }

    if (-not $identity -and -not $messageId) {
        return BadRequest("Informe 'Identity' (GUID1\\GUID2) ou 'MessageId' (RFC822, com ou sem <>).")
    }

    # Normalize MessageId: accepts with or without <>
    if ($messageId) {
        $trim = $messageId.Trim()
        if (-not ($trim.StartsWith('<') -and $trim.EndsWith('>'))) {
            $messageId = "<$trim>"
        } else {
            $messageId = $trim
        }
    }

    # ---- EXO connection via Managed Identity ----
    Connect-ExchangeOnline -ManagedIdentity -Organization $org -ShowBanner:$false `
        -CommandName Get-QuarantineMessage,Release-QuarantineMessage | Out-Null

    # ---- Resolve Identity from MessageId, if necessary ----
    if (-not $identity -and $messageId) {
        $q = Get-QuarantineMessage -MessageId $messageId -EntityType $entityType -ErrorAction Stop

        if ($null -eq $q -or $q.Count -eq 0) {
            return Write-JsonResponse -StatusCode 404 -BodyObject @{
                status = 'not_found'
                message = "Nenhum item de quarentena encontrado para MessageId $messageId."
                entityType = $entityType
            }
        }

        # Take the most recent one
        if ($q | Get-Member -Name 'ReceivedTime' -MemberType NoteProperty,Property) {
            $identity = ($q | Sort-Object ReceivedTime -Descending | Select-Object -First 1).Identity
        } elseif ($q | Get-Member -Name 'Received' -MemberType NoteProperty,Property) {
            $identity = ($q | Sort-Object Received -Descending | Select-Object -First 1).Identity
        } else {
            $identity = ($q | Select-Object -First 1).Identity
        }
    }

    if (-not $identity) {
        return Write-JsonResponse -StatusCode 404 -BodyObject @{
            status = 'not_found'
            message = "Não foi possível resolver 'Identity' para liberação."
            hint = "Verifique se o MessageId pertence a um item válido no tipo '$entityType'."
        }
    }

    # ---- Build release parameters ----
    $releaseParams = @{
        Identity = $identity
        Confirm  = $false
    }

    if ($users -and ($users | Measure-Object).Count -gt 0) {
        $releaseParams['User'] = $users
    } else {
        # If Users was not provided, defaults to ReleaseToAll=true (default) or respects the flag sent
        if ($null -ne $releaseToAll) {
            if ($releaseToAll) { $releaseParams['ReleaseToAll'] = $true }
        } else {
            $releaseParams['ReleaseToAll'] = $true
        }
    }

    if ($allowSender) { $releaseParams['AllowSender'] = $true }
    if ($reportFP)    { $releaseParams['ReportFalsePositive'] = $true }

    # ---- Execution ----
    $result = Release-QuarantineMessage @releaseParams -ErrorAction Stop

    # ---- Output ----
    return Write-JsonResponse -BodyObject @{
        status           = 'ok'
        releasedIdentity = $identity
        releasedTo       = $(if ($users -and $users.Count -gt 0) { $users } else { 'AllOriginalRecipients' })
        entityType       = $entityType
        messageIdInput   = $messageId
        raw              = $result
    }
}
catch {
    $err = $_ | Out-String
    Write-Error $err
    return Write-JsonResponse -StatusCode 500 -BodyObject @{
        status = 'error'
        error  = $err
    }
}
finally {
    try { Disconnect-ExchangeOnline -Confirm:$false | Out-Null } catch {}
}